'use client';

import React from 'react';
import DiagnosticLanding from '../../components/DiagnosticLanding';

export default function DiagnosticPage() {
  return (
    <main>
      <DiagnosticLanding />
    </main>
  );
}
